const index = (req, res) => {
    res.send("Trabajo Final Backend")    
}

module.exports = {index}